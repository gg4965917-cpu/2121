export default function Home() {
  return (
    <main>
      <h1>Forum-Catalog Frontend (PoC)</h1>
      <p>Placeholder home. Implement shop list and search here.</p>
    </main>
  )
}